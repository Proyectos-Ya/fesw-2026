var mp=(function(){"use strict";var Me=Object.defineProperty;var Re=(D,f,I)=>f in D?Me(D,f,{enumerable:!0,configurable:!0,writable:!0,value:I}):D[f]=I;var E=(D,f,I)=>Re(D,typeof f!="symbol"?f+"":f,I);function D(s){return s}const f={host:"compra-agil.mercadopublico.cl",pathPattern:/^\/resumen-cotizacion\/([^/]+)\/?$/,headerPattern:/Detalle de la cotización\s+(\S+)/,participarHeading:"Participar de la Compra Ágil",productIdPattern:/^ID:\s*(\d+)$/,labels:{unitPrice:"Valor unitario",shipping:"Despacho",detail:"Detalle cotización",validity:"Fecha de vigencia",annex:"documento anexo (opcional)"},detailMaxLength:255,annexMaxBytes:20*1024*1024,annexExtensions:[".doc",".docx",".xls",".xlsx",".pdf"]};function I(s){try{const e=new URL(s);if(e.hostname!==f.host)return null;const t=e.pathname.match(f.pathPattern);return t?decodeURIComponent(t[1]):null}catch{return null}}function J(s){return s.replace(/[^0-9kK]/g,"").toUpperCase()}const Q=s=>s.replace(/\D/g,""),P=s=>{var e;return((e=s.textContent)==null?void 0:e.trim())??""},X=s=>String(s).padStart(2,"0");function ne(s,e=new Date){const t=new Date(e.getFullYear(),e.getMonth(),e.getDate()+s);return`${X(t.getDate())}/${X(t.getMonth()+1)}/${t.getFullYear()}`}function se(s){const e=atob(s.data_base64),t=new Uint8Array(e.length);for(let r=0;r<e.length;r++)t[r]=e.charCodeAt(r);return new File([t],s.name,{type:s.type})}const ee=()=>new Promise(s=>setTimeout(s,30));class oe{constructor(e=document){E(this,"doc");this.doc=e}headerCode(){for(const e of Array.from(this.doc.querySelectorAll("h1, h2"))){const t=P(e).match(f.headerPattern);if(t)return t[1]}return null}isFormReady(){return Array.from(this.doc.querySelectorAll("h2, h3, h4")).some(t=>P(t)===f.participarHeading)&&this.findItemBlocks().length>0}waitForForm(e=3e4){return this.isFormReady()?Promise.resolve(!0):new Promise(t=>{const r=this.doc.body??this.doc.documentElement,o=new MutationObserver(()=>{this.isFormReady()&&a(!0)}),n=setTimeout(()=>a(!1),e),a=i=>{o.disconnect(),clearTimeout(n),t(i)};o.observe(r,{childList:!0,subtree:!0})})}async fill(e,t){const r=h=>({success:!1,filledCount:0,incompleteCount:0,pending:[],error:h});if(!this.isFormReady())return r("FORM_NOT_FOUND");if(this.headerCode()!==e.tender_code)return r("TENDER_CODE_MISMATCH");if(!t.sessionRut)return r("IDENTITY_UNVERIFIED");if(J(t.sessionRut)!==J(e.company_rut))return r("RUT_MISMATCH");const o=[],n=[],a=this.findItemBlocks();a.forEach((h,b)=>{const C=this.matchItem(h,b,a,e.items);if(!C){this.mark(h.input,"incomplete"),n.push(h.name);return}const v=String(Math.round(C.unit_price));o.push({el:h.input,expected:v,label:h.name,matches:_=>Q(_)===v})});const i=this.controlNear(f.labels.detail);if(i&&e.observations){const h=i.maxLength>0?i.maxLength:f.detailMaxLength,b=e.observations.slice(0,h);o.push({el:i,expected:b,label:f.labels.detail,matches:C=>C===b})}else i&&(this.mark(i,"incomplete"),n.push(f.labels.detail));const x=this.controlNear(f.labels.shipping);if(x&&typeof e.shipping_clp=="number"){const h=String(Math.round(e.shipping_clp));o.push({el:x,expected:h,label:f.labels.shipping,matches:b=>Q(b)===h})}else x&&(this.mark(x,"incomplete"),n.push(f.labels.shipping));const m=this.controlNear(f.labels.validity);if(m){const h=ne(e.validity_days);o.push({el:m,expected:h,label:f.labels.validity,matches:b=>b===h})}for(const h of o)this.setNativeValue(h.el,h.expected);await ee();let u=0;for(const h of o)h.matches(h.el.value)?(this.mark(h.el,"filled"),u++):(this.mark(h.el,"incomplete"),n.push(h.label));const w=this.pickAnnex(e.files);return n.push(...e.files.map(h=>h.name)),{success:!0,filledCount:u,incompleteCount:n.length,pending:n,...w?{annexReady:w.name}:{}}}async attachAnnex(e){var i,x;const t=this.annexInput(),r=t?this.pickAnnex(e):null,o=e.filter(m=>m!==r).map(m=>m.name);if(!t||!r)return{attached:null,pending:o};const n=new DataTransfer;n.items.add(se(r)),t.files=n.files,t.dispatchEvent(new Event("change",{bubbles:!0})),await ee();const a=((x=(i=t.files)==null?void 0:i[0])==null?void 0:x.name)===r.name;return this.mark(t,a?"filled":"incomplete"),a?{attached:r.name,pending:o}:{attached:null,pending:[r.name,...o]}}pickAnnex(e){return e.find(t=>t.size<=f.annexMaxBytes&&f.annexExtensions.some(r=>t.name.toLowerCase().endsWith(r)))??null}annexInput(){const e=this.findLabels(this.doc,f.labels.annex)[0];for(let t=(e==null?void 0:e.parentElement)??null,r=0;t&&r<4;r++,t=t.parentElement){const o=t.querySelector("input[type='file']");if(o)return o}return null}clearHighlighting(){this.doc.querySelectorAll("[data-chiripa-field-status]").forEach(e=>e.removeAttribute("data-chiripa-field-status"))}findItemBlocks(){const e=Array.from(this.doc.querySelectorAll("p, span, div")).filter(r=>r.children.length===0&&f.productIdPattern.test(P(r))),t=[];for(const r of e){let o=r.parentElement;for(let n=0;o&&n<6;n++,o=o.parentElement){const a=this.findLabels(o,f.labels.unitPrice)[0];if(!a)continue;const i=e.filter(m=>o.contains(m)).length,x=this.controlFromLabel(a,o);if(i===1&&x instanceof HTMLInputElement){const m=P(r).match(f.productIdPattern)[1],u=P(r.previousElementSibling??r)||`ID ${m}`;t.push({productId:m,name:u,input:x})}break}}return t}matchItem(e,t,r,o){const n=r.filter(i=>i.productId===e.productId).length,a=o.filter(i=>i.product_code===e.productId);if(n===1&&a.length===1)return a[0];if(o.length===r.length){const i=o[t],x=new Set(r.map(u=>u.productId)),m=o.every(u=>!u.product_code||!x.has(u.product_code));if(!i.product_code||i.product_code===e.productId||m)return i}return null}findLabels(e,t){return Array.from(e.querySelectorAll("label, span, p, div, legend")).filter(r=>P(r)===t&&!Array.from(r.children).some(o=>P(o)===t))}controlNear(e){const t=this.findLabels(this.doc,e)[0];return t?this.controlFromLabel(t,null):null}controlFromLabel(e,t){let r=e.parentElement;for(let o=0;r&&o<4;o++,r=r.parentElement){const n=r.querySelector("input[type='text']:not([disabled]):not([readonly]), input:not([type]):not([disabled]):not([readonly]), textarea:not([disabled]):not([readonly]):not([aria-hidden='true'])");if(n)return n;if(r===t)break}return null}setNativeValue(e,t){var n;const r=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,o=(n=Object.getOwnPropertyDescriptor(r,"value"))==null?void 0:n.set;o?o.call(e,t):e.value=t,e.dispatchEvent(new Event("input",{bubbles:!0}))}mark(e,t){e.setAttribute("data-chiripa-field-status",t)}}const ie="servicios-compra-agil.mercadopublico.cl",ae=/^\/v1\/compra-agil\/proveedor\/empresa\/(\d{1,2}(?:\.?\d{3}){2}-[\dkK])\/?$/;function ce(s){const e=new Set;for(const t of s)try{const r=new URL(t);if(r.hostname!==ie)continue;const o=decodeURIComponent(r.pathname).match(ae);o&&e.add(o[1].toUpperCase())}catch{}return e.size===1?[...e][0]:null}function le(s=performance){return s.getEntriesByType("resource").map(e=>e.name)}async function de(s=()=>le(),e=1e4,t=300){const r=Date.now()+e;for(;;){const o=ce(s());if(o||Date.now()>=r)return o;await new Promise(n=>setTimeout(n,t))}}class me{constructor(e=typeof document<"u"?document:{}){E(this,"document");this.document=e}extractCode(e){const t=e!==void 0?e:typeof window<"u"?window.location.search:"",o=new URLSearchParams(t).get("code");if(o)return o.trim();if(this.document.querySelector){const n=this.document.querySelector('[data-testid="tender-code"], .codigo-licitacion, h1, h2');if(n!=null&&n.textContent){const a=n.textContent.match(/\d+-\d+-(?:COT|L1|LE|LP)\d+/i);if(a)return a[0].toUpperCase()}}return null}extractCallInfo(){const e=this.document.body&&(this.document.body.innerText||this.document.body.textContent)||"",t=/segundo\s+llamado|2[°º.]?\s*llamado/i.test(e);return{call_number:t?2:1,first_call:this.extractDateByLabel(["Cierre primer llamado","Fecha de cierre"]),second_call:t?this.extractDateByLabel(["Cierre segundo llamado","Nuevo cierre"]):null}}extractAttachments(){const e=[];return this.document.querySelectorAll&&this.document.querySelectorAll('table[data-section="adjuntos"] tbody tr, .tabla-adjuntos tbody tr, tr[ng-repeat*="adjunto"], tr.attachment-row').forEach((r,o)=>{var m,u;const n=r.querySelector('.nombre-archivo, td[data-col="nombre"], a.download-link, td:nth-child(1)'),a=(m=n==null?void 0:n.textContent)==null?void 0:m.trim();if(!a)return;const x=r.getAttribute("data-id")||((u=r.querySelector("[data-doc-id]"))==null?void 0:u.getAttribute("data-doc-id"))||`mp-doc-${o+1}`;e.push({mp_document_id:x,name:a})}),e}extractDateByLabel(e){const t=this.document.body&&(this.document.body.innerText||this.document.body.textContent)||"";for(const r of e){const o=new RegExp(`${r}[:\\s]+([0-9]{2}[/-][0-9]{2}[/-][0-9]{4}(?:\\s+[0-9]{2}:[0-9]{2})?)`,"i"),n=t.match(o);if(n)return n[1]}return null}async waitForHydration(e=1e4){const t=Date.now();return new Promise(r=>{const o=()=>{const n=!!this.extractCode(),a=this.extractAttachments().length>0||!!(this.document.querySelector&&this.document.querySelector(".sin-adjuntos"));if(n&&a){r(!0);return}if(Date.now()-t>e){r(!1);return}setTimeout(o,250)};o()})}}class ge{constructor(e=document){E(this,"doc");this.doc=e}isLoginPage(){const e=!!this.doc.querySelector("form[action*='Login']")||!!this.doc.querySelector("form[action*='login']")||!!this.doc.querySelector("#lnkClaveUnica"),t=!!this.doc.querySelector("#txtUsuario");return e&&t}isPostulationForm(){return!!this.doc.querySelector("#tblItems")||!!this.doc.querySelector("#formPostulacion")||!!this.doc.querySelector(".table-items")||!!this.doc.querySelector("input[name*='precio' i]")}extractTenderCode(){const e=this.doc.getElementById("lblNumeroLicitacion")??this.doc.querySelector(".tender-header span")??this.doc.querySelector("[data-tender-code]");if(e!=null&&e.textContent){const t=e.textContent.match(/\d+-\d+-[a-zA-Z0-9]+/);return t?t[0]:e.textContent.trim()}return null}extractSessionRut(){const e=this.doc.getElementById("lblUsuarioRUT")??this.doc.querySelector(".user-session #lblUsuarioRUT")??this.doc.querySelector("[data-user-rut]");return e!=null&&e.textContent?e.textContent.trim():null}detectState(){const e=this.isLoginPage(),t=this.isPostulationForm(),r=this.extractTenderCode(),o=this.extractSessionRut();return{isLogin:e,isForm:t,canPostulate:t&&!e,tenderCode:r,sessionRut:o}}fillPostulation(e){if(!this.isPostulationForm())return{success:!1,filledCount:0,incompleteCount:0,error:"FORM_NOT_FOUND"};const t=this.extractTenderCode();if(t&&t!==e.tender_code)return{success:!1,filledCount:0,incompleteCount:0,error:"TENDER_CODE_MISMATCH"};const r=this.extractSessionRut();if(r){const u=r.replace(/\./g,"").toUpperCase(),w=e.company_rut.replace(/\./g,"").toUpperCase();if(u!==w)return{success:!1,filledCount:0,incompleteCount:0,error:"RUT_MISMATCH"}}let o=0,n=0;const a=Array.from(this.doc.querySelectorAll("#tblItems tbody tr, tr[data-line]"));a.length>0&&a.forEach((u,w)=>{const h=u.getAttribute("data-line"),b=h?parseInt(h,10):w+1,C=e.items.find(_=>_.line_number===b),v=u.querySelector("input[name*='precio' i]")??u.querySelector(`#txtPrecioUnitario_${w}`);v&&(C?(v.value=String(C.unit_price),this.dispatchChange(v),this.markFieldStatus(v,"filled"),o++):(this.markFieldStatus(v,"incomplete"),n++))});const i=this.doc.getElementById("txtObservaciones")??this.doc.querySelector("textarea[name*='observaciones' i]");if(i&&e.observations){const u=i.maxLength>0?i.maxLength:255;i.value=e.observations.slice(0,u),this.dispatchChange(i),this.markFieldStatus(i,"filled"),o++}else i&&(this.markFieldStatus(i,"incomplete"),n++);const x=this.doc.getElementById("txtPlazoEntrega")??this.doc.querySelector("input[name*='plazo' i]");x&&e.delivery_term_days&&(x.value=String(e.delivery_term_days),this.dispatchChange(x),this.markFieldStatus(x,"filled"),o++);const m=this.doc.getElementById("txtValidezOferta")??this.doc.querySelector("input[name*='validez' i]");return m&&e.validity_days&&(m.value=String(e.validity_days),this.dispatchChange(m),this.markFieldStatus(m,"filled"),o++),{success:!0,filledCount:o,incompleteCount:n}}clearHighlighting(){this.doc.querySelectorAll("[data-chiripa-field-status]").forEach(t=>t.removeAttribute("data-chiripa-field-status"))}markFieldStatus(e,t){e.setAttribute("data-chiripa-field-status",t)}dispatchChange(e){e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}}const G={FORM_NOT_FOUND:"No encontramos el formulario de cotización en esta página.",TENDER_CODE_MISMATCH:"Esta página corresponde a otra cotización. No completamos nada.",IDENTITY_UNVERIFIED:"No pudimos verificar la empresa con la que iniciaste sesión. No completamos nada.",RUT_MISMATCH:"Iniciaste sesión con otra empresa distinta a la del borrador. No completamos nada."};async function ue(s){const e=await s.getPackage(s.tenderCode);if(!e)return;const t={packageData:e,filledCount:0,incompleteCount:0,pending:[]};if(!await s.waitForForm()){s.render({...t,notice:G.FORM_NOT_FOUND});return}const r=await s.fill(e,{sessionRut:await s.getSessionRut()});if(!r.success){s.render({...t,notice:r.error?G[r.error]:G.FORM_NOT_FOUND});return}const o=r.pending.filter(a=>!e.files.some(i=>i.name===a)),n={packageData:e,filledCount:r.filledCount,incompleteCount:r.incompleteCount,pending:r.pending};r.annexReady&&(n.annexToConfirm=r.annexReady,n.onConfirmAnnex=async()=>{const a=await s.attachAnnex(e.files),i=[...o,...a.pending];s.render({packageData:e,filledCount:r.filledCount+(a.attached?1:0),incompleteCount:i.length,pending:i,annexToConfirm:void 0})}),s.render(n)}const he=`
  --ch-bg-page: #FBF8F3;
  --ch-bg-sunken: #F3EEE6;
  --ch-surface: #FFFFFF;
  --ch-surface-inset: #F3EEE6;
  --ch-text-strong: #1B1814;
  --ch-text-body: #2A2620;
  --ch-text-muted: #60584C;
  --ch-text-subtle: #847C6E;
  --ch-border-subtle: #E8E1D5;
  --ch-border-default: #D6CDBD;
  --ch-primary: #6D8657;
  --ch-primary-hover: #556B43;
  --ch-primary-active: #3F5433;
  --ch-primary-soft: #F1F5EB;
  --ch-primary-border: #C6D8B5;
  --ch-on-primary: #FBF8F3;
  --ch-accent: #DB9E23;
  --ch-success: #2F8F5B;
  --ch-success-soft: #D6EBDC;
  --ch-success-text: #237548;
  --ch-warning: #D6960F;
  --ch-warning-soft: #F8E9C7;
  --ch-warning-text: #B07A0A;
  --ch-danger: #CC3B2E;
  --ch-danger-soft: #F7D9D4;
  --ch-danger-text: #A82E23;
  --ch-ring: rgba(109, 134, 87, 0.32);
  --ch-shadow-premium: 0 12px 32px rgba(27, 24, 20, 0.10), 0 3px 8px rgba(27, 24, 20, 0.05);
  --ch-shadow-teal: 0 8px 24px rgba(45, 79, 44, 0.18);`,pe=`
  --ch-bg-page: #12110E;
  --ch-bg-sunken: #1B1814;
  --ch-surface: #1F1C18;
  --ch-surface-inset: #161411;
  --ch-text-strong: #F5F2EB;
  --ch-text-body: #DFD9CE;
  --ch-text-muted: #A69E90;
  --ch-text-subtle: #7D7567;
  --ch-border-subtle: #2E2A23;
  --ch-border-default: #3D382F;
  --ch-primary: #87A46B;
  --ch-primary-hover: #A5BF8B;
  --ch-primary-active: #6D8657;
  --ch-primary-soft: rgba(109, 134, 87, 0.20);
  --ch-primary-border: rgba(135, 164, 107, 0.35);
  --ch-on-primary: #12110E;
  --ch-success: #4ADE80;
  --ch-success-soft: rgba(20, 83, 45, 0.45);
  --ch-success-text: #86EFAC;
  --ch-warning: #FBBF24;
  --ch-warning-soft: rgba(120, 53, 15, 0.45);
  --ch-warning-text: #FCD34D;
  --ch-danger: #F87171;
  --ch-danger-soft: rgba(127, 29, 29, 0.45);
  --ch-danger-text: #FCA5A5;`,xe=`
  --ch-font-sans: "Hanken Grotesk", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  --ch-font-display: "Bricolage Grotesque", "Hanken Grotesk", system-ui, -apple-system, "Segoe UI", sans-serif;
  --ch-radius-xs: 4px;
  --ch-radius-sm: 8px;
  --ch-radius-md: 12px;
  --ch-radius-lg: 16px;`;function fe(s){return`${s} {${xe}${he}
}
@media (prefers-color-scheme: dark) {
  ${s} {${pe}
  }
}`}const Ae=`
[data-chiripa-field-status="filled"] {
  border: 2px solid #2F8F5B !important;
  background-color: #EEF7F1 !important;
  box-shadow: 0 0 0 3px rgba(47, 143, 91, 0.15) !important;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}
[data-chiripa-field-status="incomplete"] {
  border: 2px solid #D6960F !important;
  background-color: #FCF4E1 !important;
  box-shadow: 0 0 0 3px rgba(214, 150, 15, 0.18) !important;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}`,be=`${fe(":host")}
:host {
  all: initial;
  position: fixed;
  bottom: 24px;
  right: 24px;
  z-index: 2147483647;
  font-family: var(--ch-font-sans);
  color: var(--ch-text-body);
  -webkit-font-smoothing: antialiased;
}
.panel {
  width: 336px;
  background: var(--ch-surface);
  color: var(--ch-text-body);
  border: 1px solid var(--ch-border-subtle);
  border-radius: var(--ch-radius-lg);
  box-shadow: var(--ch-shadow-premium);
  padding: 16px;
  box-sizing: border-box;
  font-size: 13px;
  line-height: 1.45;
}
.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}
.title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-family: var(--ch-font-display);
  font-size: 15px;
  font-weight: 700;
  color: var(--ch-text-strong);
  letter-spacing: -0.01em;
}
.dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--ch-primary);
  box-shadow: 0 0 0 3px var(--ch-primary-soft);
}
.close-btn {
  background: none;
  border: none;
  color: var(--ch-text-subtle);
  cursor: pointer;
  font-size: 15px;
  line-height: 1;
  padding: 6px;
  border-radius: var(--ch-radius-sm);
}
.close-btn:hover {
  color: var(--ch-text-strong);
  background: var(--ch-bg-sunken);
}
.tender-info {
  font-size: 12px;
  color: var(--ch-text-muted);
  margin-bottom: 12px;
  background: var(--ch-surface-inset);
  border: 1px solid var(--ch-border-subtle);
  padding: 10px 12px;
  border-radius: var(--ch-radius-md);
}
.tender-code {
  display: block;
  font-weight: 700;
  color: var(--ch-primary-hover);
  margin-bottom: 2px;
}
.metrics {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
  margin-bottom: 12px;
}
.metric-box {
  padding: 10px;
  border-radius: var(--ch-radius-md);
  text-align: center;
  border: 1px solid var(--ch-border-subtle);
  background: var(--ch-surface-inset);
}
.metric-num {
  font-family: var(--ch-font-display);
  font-size: 20px;
  font-weight: 800;
  line-height: 1.1;
}
.metric-num.green {
  color: var(--ch-success-text);
}
.metric-num.amber {
  color: var(--ch-warning-text);
}
.metric-label {
  font-size: 11px;
  color: var(--ch-text-muted);
  margin-top: 2px;
}
.notice {
  background: var(--ch-danger-soft);
  border: 1px solid var(--ch-danger);
  color: var(--ch-danger-text);
  border-radius: var(--ch-radius-sm);
  padding: 8px 10px;
  font-size: 12px;
  margin-bottom: 10px;
}
.annex-box {
  background: var(--ch-primary-soft);
  border: 1px solid var(--ch-primary-border);
  color: var(--ch-text-body);
  border-radius: var(--ch-radius-md);
  padding: 10px 12px;
  font-size: 12px;
  margin-bottom: 10px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.pending-list {
  margin: 0 0 12px;
  padding: 8px 10px 8px 26px;
  font-size: 12px;
  color: var(--ch-warning-text);
  background: var(--ch-warning-soft);
  border-radius: var(--ch-radius-sm);
}
.pending-list li + li {
  margin-top: 2px;
}
.warning-box {
  background: var(--ch-surface-inset);
  border: 1px solid var(--ch-border-subtle);
  border-left: 3px solid var(--ch-accent);
  border-radius: var(--ch-radius-sm);
  padding: 8px 10px;
  font-size: 11px;
  color: var(--ch-text-muted);
  margin-bottom: 12px;
}
.actions {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.btn {
  display: block;
  width: 100%;
  padding: 9px 14px;
  font-family: var(--ch-font-sans);
  font-size: 12px;
  font-weight: 600;
  border-radius: var(--ch-radius-sm);
  cursor: pointer;
  text-align: center;
  box-sizing: border-box;
  transition: background-color 0.2s ease, border-color 0.2s ease, color 0.2s ease;
}
.btn:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px var(--ch-ring);
}
.btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
.btn-outline {
  background: transparent;
  border: 1px solid var(--ch-border-default);
  color: var(--ch-text-body);
}
.btn-outline:hover {
  background: var(--ch-primary-soft);
  border-color: var(--ch-primary-border);
  color: var(--ch-primary-hover);
}
.annex-box .btn-outline {
  background: var(--ch-primary);
  border-color: var(--ch-primary);
  color: var(--ch-on-primary);
  box-shadow: var(--ch-shadow-teal);
}
.annex-box .btn-outline:hover {
  background: var(--ch-primary-hover);
  border-color: var(--ch-primary-hover);
  color: var(--ch-on-primary);
}
`,ye="chiripa-postulation-panel-host";class te{constructor(e){E(this,"doc");E(this,"onClearHighlight");E(this,"onDownloadAttachments");E(this,"host",null);E(this,"shadow",null);this.doc=(e==null?void 0:e.doc)??document,this.onClearHighlight=e==null?void 0:e.onClearHighlight,this.onDownloadAttachments=e==null?void 0:e.onDownloadAttachments}render(e){this.destroy();const t=this.doc.createElement("div");t.id=ye,this.doc.body.appendChild(t);const r=t.attachShadow({mode:"open"});this.host=t,this.shadow=r;const o=this.doc.createElement("style");o.textContent=be,r.appendChild(o);const n=this.doc.createElement("div");n.className="panel";const a=this.doc.createElement("div");a.className="header";const i=this.doc.createElement("div");i.className="title";const x=this.doc.createElement("span");x.className="dot";const m=this.doc.createElement("span");m.textContent="Chiripa — Postulación Asistida",i.appendChild(x),i.appendChild(m);const u=this.doc.createElement("button");u.className="close-btn",u.textContent="✕",u.setAttribute("aria-label","Cerrar panel"),u.addEventListener("click",()=>this.destroy()),a.appendChild(i),a.appendChild(u),n.appendChild(a);const w=this.doc.createElement("div");w.className="tender-info";const h=this.doc.createElement("span");h.className="tender-code",h.textContent=e.packageData.tender_code;const b=this.doc.createElement("div");b.textContent=`${e.packageData.company_name} (${e.packageData.company_rut})`,w.appendChild(h),w.appendChild(b),n.appendChild(w);const C=this.doc.createElement("div");C.className="metrics";const v=this.doc.createElement("div");v.className="metric-box";const _=this.doc.createElement("div");_.className="metric-num green",_.textContent=String(e.filledCount);const M=this.doc.createElement("div");M.className="metric-label",M.textContent=`${e.filledCount} completados`,v.appendChild(_),v.appendChild(M);const R=this.doc.createElement("div");R.className="metric-box";const B=this.doc.createElement("div");B.className="metric-num amber",B.textContent=String(e.incompleteCount);const O=this.doc.createElement("div");if(O.className="metric-label",O.textContent=`${e.incompleteCount} pendientes`,R.appendChild(B),R.appendChild(O),C.appendChild(v),C.appendChild(R),n.appendChild(C),e.notice){const d=this.doc.createElement("div");d.className="notice",d.textContent=e.notice,n.appendChild(d)}if(e.pending&&e.pending.length>0){const d=this.doc.createElement("ul");d.className="pending-list";for(const g of e.pending){const A=this.doc.createElement("li");A.textContent=g,d.appendChild(A)}n.appendChild(d)}if(e.annexToConfirm&&e.onConfirmAnnex){const d=this.doc.createElement("div");d.className="annex-box",d.textContent=`Borrador listo: ${e.annexToConfirm}. El archivo se sube a Mercado Público apenas lo adjuntamos, aunque aún no envíes la cotización.`;const g=this.doc.createElement("button");g.id="btnChiripaConfirmAnnex",g.className="btn btn-outline",g.textContent="Subir borrador de postulación";const A=e.onConfirmAnnex;g.addEventListener("click",()=>{g.disabled=!0,A()}),d.appendChild(g),n.appendChild(d)}const N=this.doc.createElement("div");N.className="warning-box",N.textContent="⚠️ Recuerda revisar cada campo y enviar la oferta manualmente en Mercado Público. Chiripa nunca enviará la postulación por ti.",n.appendChild(N);const c=this.doc.createElement("div");c.className="actions";const l=this.doc.createElement("button");if(l.id="btnChiripaClearHighlight",l.className="btn btn-outline",l.textContent="Quitar resaltado de campos",l.addEventListener("click",()=>{this.onClearHighlight&&this.onClearHighlight()}),c.appendChild(l),e.packageData.files.length>0&&this.onDownloadAttachments){const d=this.doc.createElement("button");d.className="btn btn-outline",d.textContent=`Descargar ${e.packageData.files.length} archivo(s)`,d.addEventListener("click",()=>{var g;(g=this.onDownloadAttachments)==null||g.call(this)}),c.appendChild(d)}n.appendChild(c),r.appendChild(n),this.injectHighlightStyles()}injectHighlightStyles(){const e="chiripa-highlight-styles";if(!this.doc.getElementById(e)){const t=this.doc.createElement("style");t.id=e,t.textContent=Ae,this.doc.head.appendChild(t)}}destroy(){this.host&&this.host.parentNode&&this.host.parentNode.removeChild(this.host),this.host=null,this.shadow=null;const e=this.doc.getElementById("chiripa-highlight-styles");e&&e.parentNode&&e.parentNode.removeChild(e)}}const Ce=s=>new Promise(e=>{chrome.runtime.sendMessage({action:"GET_PENDING_POSTULATION",tender_code:s},t=>e((t==null?void 0:t.packageData)??null))});function ve(){const s=new oe(document);let e=null,t=!1;const r=async()=>{const n=I(window.location.href);if(!(!n||t)){t=!0;try{await ue({tenderCode:n,getPackage:Ce,waitForForm:()=>s.waitForForm(3e4),getSessionRut:()=>de(),fill:(a,i)=>s.fill(a,i),attachAnnex:a=>s.attachAnnex(a),render:a=>{e??(e=new te({doc:document,onClearHighlight:()=>s.clearHighlighting()})),e.render(a)}})}catch(a){console.error("[Chiripa] Error aplicando el paquete en Compra Ágil:",a)}finally{t=!1}}};r(),chrome.runtime.onMessage.addListener(n=>{(n==null?void 0:n.action)==="PACKAGE_READY"&&(n==null?void 0:n.tender_code)===I(window.location.href)&&r()});let o=window.location.href;setInterval(()=>{window.location.href!==o&&(o=window.location.href,r())},1e3)}const we={matches:["*://*.mercadopublico.cl/*"],runAt:"document_idle",async main(){if(window.location.hostname==="compra-agil.mercadopublico.cl"){ve();return}const s=new ge(document),e=s.detectState();if(e.isLogin)return;if(e.isForm&&e.tenderCode){let i=null;const x=async()=>{try{const m=await new Promise(u=>{chrome.runtime.sendMessage({action:"GET_PENDING_POSTULATION",tender_code:e.tenderCode},w=>u(w??{}))});if(m!=null&&m.packageData){const u=s.fillPostulation(m.packageData);u.success&&(i||(i=new te({doc:document,onClearHighlight:()=>s.clearHighlighting()})),i.render({packageData:m.packageData,filledCount:u.filledCount,incompleteCount:u.incompleteCount}))}}catch(m){console.error("[MP Postulation] Error cargando paquete:",m)}};await x(),chrome.runtime.onMessage.addListener(m=>{(m==null?void 0:m.action)==="PACKAGE_READY"&&(m==null?void 0:m.tender_code)===e.tenderCode&&x()});return}const t=new me(document);if(!await t.waitForHydration(5e3)||!t.extractCode())return;const n=t.extractAttachments();if(n.length===0)return;if(!document.getElementById("chiripa-extension-badge")){const i=document.createElement("div");i.id="chiripa-extension-badge",i.style.cssText=`
        position: fixed;
        bottom: 16px;
        right: 16px;
        background: #FFFFFF;
        color: #2A2620;
        border: 1px solid #E8E1D5;
        padding: 8px 14px;
        border-radius: 12px;
        font-family: "Hanken Grotesk", system-ui, -apple-system, "Segoe UI", sans-serif;
        font-size: 13px;
        font-weight: 600;
        box-shadow: 0 12px 32px rgba(27, 24, 20, 0.10), 0 3px 8px rgba(27, 24, 20, 0.05);
        z-index: 999999;
        display: flex;
        align-items: center;
        gap: 8px;
      `;const x=document.createElement("span");x.style.cssText="display:inline-block;width:8px;height:8px;border-radius:50%;background:#6D8657;box-shadow:0 0 0 3px #F1F5EB;";const m=document.createElement("span");m.textContent=`Chiripa: ${n.length} anexo(s) detectado(s)`,i.appendChild(x),i.appendChild(m),document.body.appendChild(i)}}};function Ee(s){return s&&s.__esModule&&Object.prototype.hasOwnProperty.call(s,"default")?s.default:s}var H={exports:{}},Se=H.exports,re;function Te(){return re||(re=1,(function(s,e){(function(t,r){r(s)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:Se,function(t){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)t.exports=globalThis.browser;else{const r="The message port closed before a response was received.",o=n=>{const a={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(a).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class i extends WeakMap{constructor(l,d=void 0){super(d),this.createItem=l}get(l){return this.has(l)||this.set(l,this.createItem(l)),super.get(l)}}const x=c=>c&&typeof c=="object"&&typeof c.then=="function",m=(c,l)=>(...d)=>{n.runtime.lastError?c.reject(new Error(n.runtime.lastError.message)):l.singleCallbackArg||d.length<=1&&l.singleCallbackArg!==!1?c.resolve(d[0]):c.resolve(d)},u=c=>c==1?"argument":"arguments",w=(c,l)=>function(g,...A){if(A.length<l.minArgs)throw new Error(`Expected at least ${l.minArgs} ${u(l.minArgs)} for ${c}(), got ${A.length}`);if(A.length>l.maxArgs)throw new Error(`Expected at most ${l.maxArgs} ${u(l.maxArgs)} for ${c}(), got ${A.length}`);return new Promise((S,T)=>{if(l.fallbackToNoCallback)try{g[c](...A,m({resolve:S,reject:T},l))}catch(p){console.warn(`${c} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,p),g[c](...A),l.fallbackToNoCallback=!1,l.noCallback=!0,S()}else l.noCallback?(g[c](...A),S()):g[c](...A,m({resolve:S,reject:T},l))})},h=(c,l,d)=>new Proxy(l,{apply(g,A,S){return d.call(A,c,...S)}});let b=Function.call.bind(Object.prototype.hasOwnProperty);const C=(c,l={},d={})=>{let g=Object.create(null),A={has(T,p){return p in c||p in g},get(T,p,F){if(p in g)return g[p];if(!(p in c))return;let y=c[p];if(typeof y=="function")if(typeof l[p]=="function")y=h(c,c[p],l[p]);else if(b(d,p)){let L=w(p,d[p]);y=h(c,c[p],L)}else y=y.bind(c);else if(typeof y=="object"&&y!==null&&(b(l,p)||b(d,p)))y=C(y,l[p],d[p]);else if(b(d,"*"))y=C(y,l[p],d["*"]);else return Object.defineProperty(g,p,{configurable:!0,enumerable:!0,get(){return c[p]},set(L){c[p]=L}}),y;return g[p]=y,y},set(T,p,F,y){return p in g?g[p]=F:c[p]=F,!0},defineProperty(T,p,F){return Reflect.defineProperty(g,p,F)},deleteProperty(T,p){return Reflect.deleteProperty(g,p)}},S=Object.create(c);return new Proxy(S,A)},v=c=>({addListener(l,d,...g){l.addListener(c.get(d),...g)},hasListener(l,d){return l.hasListener(c.get(d))},removeListener(l,d){l.removeListener(c.get(d))}}),_=new i(c=>typeof c!="function"?c:function(d){const g=C(d,{},{getContent:{minArgs:0,maxArgs:0}});c(g)}),M=new i(c=>typeof c!="function"?c:function(d,g,A){let S=!1,T,p=new Promise(U=>{T=function(k){S=!0,U(k)}}),F;try{F=c(d,g,T)}catch(U){F=Promise.reject(U)}const y=F!==!0&&x(F);if(F!==!0&&!y&&!S)return!1;const L=U=>{U.then(k=>{A(k)},k=>{let Z;k&&(k instanceof Error||typeof k.message=="string")?Z=k.message:Z="An unexpected error occurred",A({__mozWebExtensionPolyfillReject__:!0,message:Z})}).catch(k=>{console.error("Failed to send onMessage rejected reply",k)})};return L(y?F:p),!0}),R=({reject:c,resolve:l},d)=>{n.runtime.lastError?n.runtime.lastError.message===r?l():c(new Error(n.runtime.lastError.message)):d&&d.__mozWebExtensionPolyfillReject__?c(new Error(d.message)):l(d)},B=(c,l,d,...g)=>{if(g.length<l.minArgs)throw new Error(`Expected at least ${l.minArgs} ${u(l.minArgs)} for ${c}(), got ${g.length}`);if(g.length>l.maxArgs)throw new Error(`Expected at most ${l.maxArgs} ${u(l.maxArgs)} for ${c}(), got ${g.length}`);return new Promise((A,S)=>{const T=R.bind(null,{resolve:A,reject:S});g.push(T),d.sendMessage(...g)})},O={devtools:{network:{onRequestFinished:v(_)}},runtime:{onMessage:v(M),onMessageExternal:v(M),sendMessage:B.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:B.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},N={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return a.privacy={network:{"*":N},services:{"*":N},websites:{"*":N}},C(n,O,a)};t.exports=o(chrome)}})})(H)),H.exports}var Fe=Te();const $=Ee(Fe);function z(s,...e){}const ke={debug:(...s)=>z(console.debug,...s),log:(...s)=>z(console.log,...s),warn:(...s)=>z(console.warn,...s),error:(...s)=>z(console.error,...s)},j=class j extends Event{constructor(e,t){super(j.EVENT_NAME,{}),this.newUrl=e,this.oldUrl=t}};E(j,"EVENT_NAME",W("wxt:locationchange"));let V=j;function W(s){var e;return`${(e=$==null?void 0:$.runtime)==null?void 0:e.id}:mp:${s}`}function _e(s){let e,t;return{run(){e==null&&(t=new URL(location.href),e=s.setInterval(()=>{let r=new URL(location.href);r.href!==t.href&&(window.dispatchEvent(new V(r,t)),t=r)},1e3))}}}const q=class q{constructor(e,t){E(this,"isTopFrame",window.self===window.top);E(this,"abortController");E(this,"locationWatcher",_e(this));E(this,"receivedMessageIds",new Set);this.contentScriptName=e,this.options=t,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return $.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener("abort",e),()=>this.signal.removeEventListener("abort",e)}block(){return new Promise(()=>{})}setInterval(e,t){const r=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(r)),r}setTimeout(e,t){const r=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(r)),r}requestAnimationFrame(e){const t=requestAnimationFrame((...r)=>{this.isValid&&e(...r)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){const r=requestIdleCallback((...o)=>{this.signal.aborted||e(...o)},t);return this.onInvalidated(()=>cancelIdleCallback(r)),r}addEventListener(e,t,r,o){var n;t==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(n=e.addEventListener)==null||n.call(e,t.startsWith("wxt:")?W(t):t,r,{...o,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),ke.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:q.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(e){var n,a,i;const t=((n=e.data)==null?void 0:n.type)===q.SCRIPT_STARTED_MESSAGE_TYPE,r=((a=e.data)==null?void 0:a.contentScriptName)===this.contentScriptName,o=!this.receivedMessageIds.has((i=e.data)==null?void 0:i.messageId);return t&&r&&o}listenForNewerScripts(e){let t=!0;const r=o=>{if(this.verifyScriptStartedEvent(o)){this.receivedMessageIds.add(o.data.messageId);const n=t;if(t=!1,n&&(e!=null&&e.ignoreFirstEvent))return;this.notifyInvalidated()}};addEventListener("message",r),this.onInvalidated(()=>removeEventListener("message",r))}};E(q,"SCRIPT_STARTED_MESSAGE_TYPE",W("wxt:content-script-started"));let Y=q;const Ie=Symbol("null");let Pe=0;class Ne extends Map{constructor(...e){super(),this._objectHashes=new WeakMap,this._symbolHashes=new Map,this._publicKeys=new Map;const[t]=e;if(t!=null){if(typeof t[Symbol.iterator]!="function")throw new TypeError(typeof t+" is not iterable (cannot read property Symbol(Symbol.iterator))");for(const[r,o]of t)this.set(r,o)}}_getPublicKeys(e,t=!1){if(!Array.isArray(e))throw new TypeError("The keys parameter must be an array");const r=this._getPrivateKey(e,t);let o;return r&&this._publicKeys.has(r)?o=this._publicKeys.get(r):t&&(o=[...e],this._publicKeys.set(r,o)),{privateKey:r,publicKey:o}}_getPrivateKey(e,t=!1){const r=[];for(const o of e){const n=o===null?Ie:o;let a;if(typeof n=="object"||typeof n=="function"?a="_objectHashes":typeof n=="symbol"?a="_symbolHashes":a=!1,!a)r.push(n);else if(this[a].has(n))r.push(this[a].get(n));else if(t){const i=`@@mkm-ref-${Pe++}@@`;this[a].set(n,i),r.push(i)}else return!1}return JSON.stringify(r)}set(e,t){const{publicKey:r}=this._getPublicKeys(e,!0);return super.set(r,t)}get(e){const{publicKey:t}=this._getPublicKeys(e);return super.get(t)}has(e){const{publicKey:t}=this._getPublicKeys(e);return super.has(t)}delete(e){const{publicKey:t,privateKey:r}=this._getPublicKeys(e);return!!(t&&super.delete(t)&&this._publicKeys.delete(r))}clear(){super.clear(),this._symbolHashes.clear(),this._publicKeys.clear()}get[Symbol.toStringTag](){return"ManyKeysMap"}get size(){return super.size}}new Ne;function Le(){}function K(s,...e){}const De={debug:(...s)=>K(console.debug,...s),log:(...s)=>K(console.log,...s),warn:(...s)=>K(console.warn,...s),error:(...s)=>K(console.error,...s)};return(async()=>{try{const{main:s,...e}=we,t=new Y("mp",e);return await s(t)}catch(s){throw De.error('The content script "mp" crashed on startup!',s),s}})()})();
mp;
